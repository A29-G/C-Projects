#ifndef MAIN_H
#define MAIN_H

#define MAX_CONTACTS 200

struct address_book 
{
    char name[20];
    char mob_no[11];
    char mail_id[30];
};

void create_contact(struct address_book contacts[], int *index);
void search_contact(struct address_book contacts[], int *index);
void edit_contact(struct address_book contacts[], int *index);
void delete_contact(struct address_book contacts[], int *index);
void list_contact(struct address_book contacts[], int *index);
void load_contacts(struct address_book contacts[], int *index);
void save_contacts(struct address_book contacts[], int index);
void edit_name(struct address_book contacts[], int i, int *index);
void edit_mob_no(struct address_book contacts[], int i, int *contact_count);
void edit_mail_id(struct address_book contacts[], int i, int *contact_count);

#endif 

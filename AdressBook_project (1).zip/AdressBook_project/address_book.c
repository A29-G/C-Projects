/*
NAME: Aishwarya Giriyal
Project: Addressbook Project
*/

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "main.h"
#define FILENAME "address_book.csv"  // Filename to store contacts
#define MAX_CONTACTS 200  // Maximum number of contacts allowed

// Define the structure to hold contact details
struct address_book contacts[MAX_CONTACTS]; 
int contact_count = 0;  // Variable to keep track of the number of contacts

int main() 
{
    int choice;
    load_contacts(contacts, &contact_count);  // Load contacts from the file at the start
    do 
    {
        // Display the menu options
        printf("\n--- Address Book Menu ---\n");
        printf("1. Create contact\n");
        printf("2. Search contact\n");
        printf("3. Edit contact\n");
        printf("4. Delete contact\n");
        printf("5. List contacts\n");
        printf("6. Exit\n");
        printf("\nEnter your choice: ");
        
        if (scanf("%d", &choice) != 1) 
        {
            // Handle invalid input for menu choice
            printf("Invalid input. Please enter a number.\n");
            while (getchar() != '\n');  // Clear input buffer
            continue;
        }

        // Switch case to handle different user actions
        switch (choice) 
        {
            case 1:
                create_contact(contacts, &contact_count);  // Create a new contact
                break;
            case 2:
                search_contact(contacts, &contact_count);  // Search for an existing contact
                break;
            case 3:
                edit_contact(contacts, &contact_count);  // Edit an existing contact
                break;
            case 4:
                delete_contact(contacts, &contact_count);  // Delete a contact
                break;
            case 5:
                list_contact(contacts, &contact_count);  // List all contacts
                break;
            case 6:
                printf("Exiting program...\n");
                save_contacts(contacts, contact_count);  // Save contacts to file before exiting
                break;
            default:
                printf("Invalid choice. Please try again.\n");
                break;
        }
    } while(choice != 6);  // Loop until user chooses to exit

    return 0;
}

// Function to load contacts from file
void load_contacts(struct address_book contacts[], int *index)
{
    FILE *fp = fopen(FILENAME, "r");  // Open file in read mode
    if (fp == NULL) {
        printf("No saved contacts found.\n");
        return;
    }

    // Read contacts from file
    while(fscanf(fp, "%19s %10s %29s", contacts[*index].name, contacts[*index].mob_no, contacts[*index].mail_id) == 3)
    {
        (*index)++;  // Increment the contact count
    }

    fclose(fp);  // Close the file
    printf("\nLoaded %d contacts from file.\n", *index);
}

// Function to save contacts to file
void save_contacts(struct address_book contacts[], int index) 
{
    FILE *fp = fopen(FILENAME, "w");  // Open file in write mode
    if (fp == NULL) {
        printf("Error saving contacts to file.\n");
        return;
    }

    // Write contacts to file
    for (int i = 0; i < index; i++) 
    {
        fprintf(fp, "%s %s %s\n", contacts[i].name, contacts[i].mob_no, contacts[i].mail_id);
    }

    fclose(fp);  // Close the file
    printf("Contacts saved to file.\n");
}

// Function to create a new contact
void create_contact(struct address_book contacts[], int *index) 
{
    if (*index >= MAX_CONTACTS) 
    {
        printf("Contact list is full\n");
        return;
    }
    int var;

    // Input validation for contact name
    while(1)
    {
        printf("Enter name: ");
        scanf(" %[^\n]", contacts[*index].name);

        var = 1;
        for (int i = 0; i < strlen(contacts[*index].name); i++) 
        {
            if (!(isalpha(contacts[*index].name[i])) && !(isspace(contacts[*index].name[i]))) 
            {
                var = 0;
                printf("Invalid name. Name must contain only alphabets. Please try again.\n");
                printf("Enter name: ");
                scanf(" %[^\n]", contacts[*index].name);
                break;
            }
        }
        if(var)
            break;
    }

    // Input validation for mobile number
    var = 0;
    printf("Enter mobile number (10 digits): ");
    scanf("%10s", contacts[*index].mob_no);

    while (var == 0) 
    {
        var = 1;
        if (strlen(contacts[*index].mob_no) != 10) 
        {
            var = 0;
            printf("Invalid mobile number. Must be 10 digits long. Please try again.\n");
            printf("Enter mobile number (10 digits): ");
            scanf("%10s", contacts[*index].mob_no);
        } 
        else 
        {
            for (int i = 0; i < 10; i++) 
            {
                if (!isdigit(contacts[*index].mob_no[i])) 
                {
                    var = 0;
                    printf("Invalid mobile number. Must contain only digits. Please try again.\n");
                    printf("Enter mobile number (10 digits): ");
                    scanf("%10s", contacts[*index].mob_no);
                    break;
                }
            }
            // Ensure mobile number is unique
            if(var && *index > 0)
            {
                for(int i = 0; i < *index; i++)
                {
                    if(strcmp(contacts[i].mob_no,contacts[*index].mob_no) == 0)
                    {
                        var = 0;
                        printf("Mobile number must be unique. Please enter again.\n");
                        printf("Enter mobile number (10 digits): ");
                        scanf("%10s", contacts[*index].mob_no);
                        break;
                    }
                }
            }
        }
    }

    // Input validation for email
    var = 0;
    printf("Enter email ID: ");
    scanf(" %[^\n]", contacts[*index].mail_id);

    while (var == 0) 
    {
        var = 1;
        char *at = strchr(contacts[*index].mail_id, '@');
        char *dot = strrchr(contacts[*index].mail_id, '.');  

        if (at == NULL || dot == NULL || dot <= at + 1) 
        {
            var = 0;
            printf("Invalid email ID. Please try again.\n");
            printf("Enter email ID: ");
            scanf(" %[^\n]", contacts[*index].mail_id);
        }
        else
        {
            for(char *ptr = contacts[*index].mail_id ; ptr < at ; ptr++)
            {
                if(!isalnum(*ptr))
                {
                    var = 0;
                    printf("Invalid email ID. The part before '@' must contain only letters or digits.\n");
                    printf("Enter email ID: ");
                    scanf(" %[^\n]", contacts[*index].mail_id);
                    break;
                }
            }
            if(var)
            {
                for(char *ptr = at+1; ptr< dot ; ptr++)
                {
                    if(!isalnum(*ptr))
                    {
                        var = 0;
                        printf("Invalid email ID. The part before '@' must contain only letters or digits.\n");
                        printf("Enter email ID: ");
                        scanf(" %[^\n]", contacts[*index].mail_id);
                        break;
                    }
                }
            }
        }
    }

    // Successfully created the contact
    printf("Contact created successfully!\n");
    (*index)++;  // Increment contact count

    save_contacts(contacts, *index);  // Save the new contact to the file
}

// Function to list all contacts
void list_contact(struct address_book contacts[], int *contact_count) 
{
    if (*contact_count == 0) 
    {
        printf("No contacts to display.\n");
        return;
    }

    // Display details of each contact
    for (int i = 0; i < *contact_count; i++) 
    {
        printf("\nIndex number: %d\n", i);
        printf("Name: %s\n", contacts[i].name);
        printf("Mobile: %s\n", contacts[i].mob_no);
        printf("Email: %s\n", contacts[i].mail_id);
    }
}

// Function to search contacts based on name, mobile number, or email
void search_contact(struct address_book contacts[], int *contact_count) 
{
    char name1[20];
    char mob_no1[11];
    char mail_id1[30];
    int opt;
    
    printf("Choose field to search:\n1. Name\n2. Mobile number\n3. Email\n");
    scanf("%d", &opt);

    switch (opt) 
    {
        case 1:
            printf("\nEnter name: ");
            scanf(" %[^\n]", name1);

            for (int i = 0; i < *contact_count; i++) 
            {
                if (strcasecmp(contacts[i].name, name1) == 0) 
                {
                    printf("\nContact found:\n");
                    printf("Name: %s\n", contacts[i].name);
                    printf("Mobile: %s\n", contacts[i].mob_no);
                    printf("Email: %s\n", contacts[i].mail_id);
                    return;
                }
            }
            break;

        case 2:
            printf("\nEnter mobile number: ");
            scanf("%s", mob_no1);

            for (int i = 0; i < *contact_count; i++) 
            {
                if (strcmp(contacts[i].mob_no, mob_no1) == 0) 
                {
                    printf("\nContact found:\n");
                    printf("Name: %s\n", contacts[i].name);
                    printf("Mobile: %s\n", contacts[i].mob_no);
                    printf("Email: %s\n", contacts[i].mail_id);
                    return;
                }
            }
            break;

        case 3:
            printf("\nEnter email: ");
            scanf(" %[^\n]", mail_id1);

            for (int i = 0; i < *contact_count; i++) 
            {
                if (strcmp(contacts[i].mail_id, mail_id1) == 0) 
                {
                    printf("\nContact found:\n");
                    printf("Name: %s\n", contacts[i].name);
                    printf("Mobile: %s\n", contacts[i].mob_no);
                    printf("Email: %s\n", contacts[i].mail_id);
                    return;
                }
            }
            break;

        default:
            printf("Invalid option.\n");
            return;
    }

    printf("Contact not found.\n");
}

// Function to edit an existing contact
void edit_contact(struct address_book contacts[], int *contact_count) 
{
    int index;
    printf("Enter index number of the contact to edit: ");
    scanf("%d", &index);

    if (index < 0 || index >= *contact_count) 
    {
        printf("Invalid index.\n");
        return;
    }

    // Edit name
    printf("Editing contact: %s\n", contacts[index].name);
    printf("Enter new name: ");
    scanf(" %[^\n]", contacts[index].name);

    // Edit mobile number
    printf("Enter new mobile number: ");
    scanf("%s", contacts[index].mob_no);

    // Edit email
    printf("Enter new email: ");
    scanf(" %[^\n]", contacts[index].mail_id);

    printf("Contact updated successfully!\n");

    save_contacts(contacts, *contact_count);  // Save the updated contacts to the file
}

void delete_contact(struct address_book contacts[], int *contact_count) 
{
    int ind;

    list_contact(contacts, contact_count);
    
    printf("\nEnter the index of the contact to delete: ");
    scanf("%d", &ind);

    if(ind >= 0 && ind < *contact_count )
    {
        for(int i = ind ; i < *contact_count - 1; i++)
        {
            contacts[i] = contacts[i+1];
        }
        (*contact_count)--;
        printf("Contact deleted successfully\n");
        save_contacts(contacts, *contact_count);
    }
    else
    {
        printf("Invalid index\n");
    }
}